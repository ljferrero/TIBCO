#!/bin/bash

#
# Copyright (c) 2018-2018 by TIBCO Software Inc.
# ALL RIGHTS RESERVED
#
# $Id: spawncheck.sh 101394 2018-05-23 18:31:46Z $
#
# Shared utility script for sample liveness and readiness probes.
#

if [[ ! $(type -P "params.sh") ]] ; then
    echo "ERROR: Missing supporting script params.sh"
    exit -1
fi

# Define available options in whitelists
# CAUTION: Whitelist should have leading and trailing spaces for simple shell matching
param_whitelist=" spawnTimeout "
flag_whitelist=" ready "
source params.sh

usage="
Usage: $cmd [<arguments>] [-- <tibemsstate arguments>]
   where <arguments> are:
   
   -spawnTimeout     <timeout>   - timeout for spawning tibemsstate (in seconds)
   -ready                        - spawn a readiness check application (instead of a liveness check)

   and <tibemsstate arguments> are described in the following help sections:

   `tibemsstate -help`

   `tibemsstate -help-ssl`

"

if [[ -z $spawnTimeout ]] ; then
    usage_exit "ERROR: missing necessary params, all are required."
fi

outputFile=/opt/tibco/ems/kubernetes/probes/output/server.state
stateChecker=tibemslive
if [[ $ready ]] ; then
    stateChecker=tibemsready
fi

# Spawn a state checker application in the background with all output sent to
# a file at a known location.
$stateChecker $extra_args | while read line; do echo "$line" > $outputFile 2>&1 ; done &
pid=`ps -ae | grep $stateChecker | awk '{print $1}'`
timer=0
while [ $timer -lt $spawnTimeout ]
do
    # Check state checker's outputFile for a string indicating that it has successfully
    # connected to the configured EMS server.
    grep -e "TEST FULLY STARTED" -e "Success" $outputFile
    if [[ $? -eq 0 ]] ; then
        # On first run, kill state checker to reap any children or lingering sessions.
        # This is done to avoid an issue where the first probe sent needs to exit cleanly with no lingering children,
        # otherwise the probe will hang.
        if [[ ! -e ${stateChecker}.tmp ]] ; then
            touch ${stateChecker}.tmp
            kill $pid
        fi
        # state checker successfully connected to the EMS server, so return success.
        exit 0
    fi
    # state checker has not yet connected to the EMS server, so sleep a second and check again.
    timer=$((timer + 1))
    sleep 1
done

# Kill state checker in case it is still attempting to connect to the EMS server.
kill $pid
wait

# state checker never successfully connected to the configured EMS server, so return failure.
exit -1
