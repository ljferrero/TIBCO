#!/bin/bash

#
# Copyright (c) 2018-2018 by TIBCO Software Inc.
# ALL RIGHTS RESERVED
#
# $Id: ready.sh 101394 2018-05-23 18:31:46Z $
#
# Sample readiness probe for tibemsd.
#

if [[ ! $(type -P "params.sh") || ! $(type -P "spawnready") ]] ; then
    echo "ERROR: Missing supporting scripts params.sh and/or spawnready"
    exit -1
fi

# Define available options in whitelists
# CAUTION: Whitelist should have leading and trailing spaces for simple shell matching
param_whitelist=" spawnTimeout responseTimeout "
flag_whitelist="  "
source params.sh

usage="
Usage: $cmd [<arguments>] [-- <tibemsstate arguments>]
   where <arguments> are:
   
   -spawnTimeout     <timeout>   - timeout for spawning tibemsstate (in seconds)
   -responseTimeout  <timeout>   - timeout for server to respond to a client request from tibemsstate (in seconds)

   and <tibemsstate arguments> are described in the following help sections:

   `tibemsstate -help`

   `tibemsstate -help-ssl`

"

if [[ -z $spawnTimeout || -z $responseTimeout ]] ; then
    usage_exit "ERROR: missing necessary params, all are required."
fi

spawnArgs="-spawnTimeout $spawnTimeout -ready"
outputFile=/opt/tibco/ems/kubernetes/probes/output/server.state

extraArgs=
if [[ $extra_args ]] ; then
    extraArgs="-- $extra_args"
fi

cd /opt/tibco/ems/kubernetes/probes/output

spawner=spawnready
stateChecker=tibemsready

# Check for a running state checker application.
# This application is needed to query the server for its state.
ps -ae | grep -v defunct | grep $stateChecker
running=$?
checkerPid=
if [[ $running -eq 0 ]] ; then
    # A valid state checker application has a paired spawner process.
    # Check for the spawner as well to verify that the state checker is properly running.
    checkerPid=`ps -ae | grep $stateChecker | awk '{print $1}'`
    ps -ae | grep -v defunct | grep $spawner
    running=$((running+$?))
fi

if [[ $running -ne 0 ]] ; then
    # Clean up the zombie state checker (its paired spawner process is not running or is defunct). 
    if [[ $checkerPid ]] ; then
        kill $checkerPid
    fi
    # State checker application is not running, so attempt to spawn it.
    $spawner $spawnArgs $extraArgs
    if [[ $? -ne 0 ]] ; then
        # The state checker application failed to spawn, so the server is not live.
        exit -1
    fi
fi

# On first run, trust the spawner's exit code. This is done to avoid an issue where
# the first probe sent needs to exit cleanly with no lingering children, otherwise the probe will hang.
if [[ ! -e ${stateChecker}.2.tmp ]] ; then
    touch ${stateChecker}.2.tmp
    exit 0
fi

readyString="Success"

# Clear last server state response from state checker application,
# and then wait for a new, successful response to appear.
echo "truncated" > $outputFile
timer=0
while [ $timer -lt $responseTimeout ]
do
    # Check state checker's outputFile for a successful state response from the server.
    tail -n 1 $outputFile | grep $readyString
    if [[ $? -eq 0 ]] ; then
        # The server reported its state to state checker after the outputFile was truncated,
        # so the server is ready.
        exit 0
    fi
    # No new response from the server has been seen, so sleep for a second and retry.
    timer=$((timer + 1))
    sleep 1
done

# No new response from the server was seen within the responseTimeout, so the server
# is not ready.
exit -1
