#!/bin/bash

#
# Copyright (c) 2018-2018 by TIBCO Software Inc.
# ALL RIGHTS RESERVED
#
# $Id: params.sh 101325 2018-05-16 17:59:24Z $
#
# Shared utility script for sample liveness and readiness probes.
#
# This script is a shared utility for other bash scripts. It establishes a couple useful
# exit functions along with a command-line argument parser. Onced sourced within a 
# bash script that defines a proper param_whitelist and flag_whitelist, the parameters
# passed to the script will be defined sensibly within the file.
# (e.g. -flag1 -param1 val1 -param2 val2 -> $flag1=true, $param1=val1, $param2=$val2)
# Additionally, $extra_args will be outputted as anything sent to the script after a '--'
# argument. (e.g. -param1 val1 -- -arg1 a -flag3 -> $param1=val1, $extra_args=-arg1 a -flag3)
#

cmd="${0##*/}"

function die {
    msg="$1"
    echo "$msg"
    exit -1
}

# Define available options in whitelists
# CAUTION: Whitelist should have leading and trailing spaces for simple shell matching
if [[ -z $param_whitelist || -z $flag_whitelist ]] ; then
    die "no whitelists available"
fi

usage="
$cmd [options]

NOTE: This script requires -<name> <value> or -<flag> options
Available params: $param_whitelist
Available flags: $flag_whitelist
"
function usage_exit
{
    echo "$*"
    echo "$usage"
    exit 1
}

#Get option settings as env-items / shell variables
while [ $# -gt 0 ] ; do arg="$1"  
    case "$arg" in 
        --) break ;; #explicit end of arguments
        -[a-zA-Z]*) name="${arg/-/}"
            if [[ "$param_whitelist" =~ " $name " ]] ; then
                val="$2"
                shift
            elif [[ "$flag_whitelist" =~ " $name " ]] ; then
                val=true
            else
                usage_exit "Invalid option: -$name"
            fi
            export $name="${val}"
            ;;
        -help) usage_exit ;;
        -v) verbose=true ;;
        *) #PICK ONE: break or fail ...
           #break - if fallthru and process positionals
            echo "Invalid option: $arg"
            usage_exit ;; #If positionals are not allowed
    esac ; shift
done

extra_args=
# Place the rest of the args on $extra_args
shift
while [ $# -gt 0 ] ; do arg="$1" 
    extra_args="$extra_args $arg"
    shift
done
