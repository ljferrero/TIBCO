#!/bin/bash

#
# Copyright (c) 2018-2018 by TIBCO Software Inc.
# ALL RIGHTS RESERVED
#
# $Id: live.sh 101325 2018-05-16 17:59:24Z $
#
# Sample liveness probe for tibemsd.
#

if [[ ! $(type -P "params.sh") || ! $(type -P "spawnlive") ]] ; then
    echo "ERROR: Missing supporting scripts params.sh and/or spawnlive"
    exit -1
fi

# Define available options in whitelists
# CAUTION: Whitelist should have leading and trailing spaces for simple shell matching
param_whitelist=" spawnTimeout "
flag_whitelist="  "
source params.sh

usage="
Usage: $cmd [<arguments>] [-- <tibemsstate arguments>]
   where <arguments> are:
   
   -spawnTimeout  <timeout>      - timeout for spawning tibemsstate (in seconds)

   and <tibemsstate arguments> are described in the following help sections:

   `tibemsstate -help`

   `tibemsstate -help-ssl`

"

if [[ -z $spawnTimeout ]] ; then
    usage_exit "ERROR: missing necessary params, all are required."
fi

spawnArgs="-spawnTimeout $spawnTimeout"

extraArgs="-- -nostate"
if [[ $extra_args ]] ; then
    extraArgs="$extraArgs $extra_args"
fi

cd /opt/tibco/ems/kubernetes/probes/output

spawner=spawnlive
heartbeatChecker=tibemslive

# Check for a running heartbeat checker application.
# A server is live by virtue of that application running.
ps -ae | grep -v defunct | grep $heartbeatChecker
running=$?
checkerPid=
if [[ $running -eq 0 ]] ; then
    # A valid heartbeat checker application has a paired spawner process.
    # Check for the spawner as well to verify that the heartbeat checker is properly running.
    checkerPid=`ps -ae | grep $heartbeatChecker | awk '{print $1}'`
    ps -ae | grep -v defunct | grep $spawner
    running=$((running+$?))
fi

if [[ $running -ne 0 ]] ; then
    # Clean up the zombie heartbeat checker (its paired spawner process is not running or is defunct). 
    if [[ $checkerPid ]] ; then
        kill $checkerPid
    fi
    # The heartbeat checker application is not running, so attempt to spawn it.
    $spawner $spawnArgs $extraArgs
    if [[ $? -ne 0 ]] ; then
        # The heartbeat checker application failed to spawn, so the server is not live.
        exit -1
    fi
fi

# The heartbeat checker application is running, so the server is live.
exit 0
